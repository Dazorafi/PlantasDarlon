"""Importa o arquivo oficial, mantendo teste oficial e agrupamento de folhas.

Não extrai caminhos arbitrários do ZIP nem sobrescreve um dataset existente.
Download explícito: python preparar_plantvillage.py --baixar
"""
import ambiente  # caches e temporários no disco do projeto

import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path, PurePosixPath
import random
import shutil
import urllib.request
import zipfile
from catalogo import CATALOGO, validar_classes

RAIZ = Path(__file__).resolve().parent
REPOSITORIO = "mohanty/PlantVillage"
REVISAO_PADRAO = "9e97599868962bd0079b8db4b7f1efa9185fa1e7"
ARQUIVOS = ("data.zip", "leaf_grouping/leaf-map.json", "splits/color_train.txt", "splits/color_test.txt")


def baixar(cache, revisao=REVISAO_PADRAO):
    cache.mkdir(parents=True, exist_ok=True)
    referencia = cache / "revisao.json"
    if referencia.exists():
        salvo = json.loads(referencia.read_text(encoding="utf-8"))["revisao"]
        if salvo != revisao:
            raise ValueError("O cache pertence a outra revisão do dataset. Use outro --cache para não misturar versões.")
    else:
        referencia.write_text(json.dumps({"repositorio": REPOSITORIO, "revisao": revisao}), encoding="utf-8")
    for nome in ARQUIVOS:
        destino = cache / nome
        if destino.exists():
            print(f"Reutilizando {nome}", flush=True)
            continue
        destino.parent.mkdir(parents=True, exist_ok=True)
        parcial = destino.with_name(destino.name + ".download")
        print(f"Baixando {nome} (o pacote completo pode ocupar vários GB)...", flush=True)
        url = f"https://huggingface.co/datasets/{REPOSITORIO}/resolve/{revisao}/{nome}"
        with urllib.request.urlopen(url, timeout=120) as origem, parcial.open("wb") as saida:
            shutil.copyfileobj(origem, saida, 1024 * 1024)
        parcial.replace(destino)


def grupo_folha(caminho, mapa):
    classe = PurePosixPath(caminho).parts[2]
    nome = PurePosixPath(caminho).name.replace("_final_masked", "")
    identificador = PurePosixPath(nome.split("___")[-1]).stem
    identificador = identificador.split("copy")[0].lower().strip()
    candidatos = mapa.get(identificador, [])
    for candidato in candidatos:
        if candidato.startswith(classe + ":::"):
            return candidato, True
    # Conserva variantes com o mesmo identificador juntas; não presume que
    # arquivos diferentes sem mapeamento sejam folhas físicas diferentes.
    return classe + ":::sem_mapa:" + identificador, False


def planejar(cache, classes, fracao=0.15, seed=42):
    validar_classes(classes)
    if not 0 < fracao < 0.5:
        raise ValueError("A fração de validação deve estar entre 0 e 0,5.")
    mapa = json.loads((cache / "leaf_grouping/leaf-map.json").read_text(encoding="utf-8"))
    registros = []
    caminhos = set()
    for split in ("train", "test"):
        for linha in (cache / f"splits/color_{split}.txt").read_text(encoding="utf-8").splitlines():
            linha = linha.strip()
            if not linha:
                continue
            partes = PurePosixPath(linha).parts
            if len(partes) != 4 or partes[:2] != ("raw", "color") or any(p in ("..", ".") or "\\" in p or ":" in p for p in partes):
                raise ValueError(f"Caminho inválido no manifesto: {linha}")
            classe = partes[2]
            if classe not in classes:
                continue
            if linha in caminhos:
                raise ValueError(f"Imagem repetida nos manifestos: {linha}")
            caminhos.add(linha)
            grupo, conhecido = grupo_folha(linha, mapa)
            registros.append({"origem": linha, "classe": classe, "split": split, "origem_split": split, "grupo": grupo, "folha_mapeada": conhecido})
    return dividir(registros, classes, fracao, seed)


def dividir(registros, classes, fracao, seed):
    # Mantém o teste oficial e exclui do treino qualquer grupo que também esteja
    # no teste. Isso cobre variantes "copy" não identificadas no mapa oficial.
    grupos_teste = {r["grupo"] for r in registros if r["origem_split"] == "test"}
    registros = [r for r in registros if r["origem_split"] == "test" or r["grupo"] not in grupos_teste]
    for r in registros:
        r["split"] = r["origem_split"]
    treino = defaultdict(set)
    teste = set()
    classes_teste = set()
    for r in registros:
        if r["split"] == "train":
            treino[r["classe"]].add(r["grupo"])
        else:
            teste.add(r["grupo"])
            classes_teste.add(r["classe"])
    todos_treino = set().union(*treino.values()) if treino else set()
    if todos_treino & teste:
        raise ValueError("Falha ao separar os grupos de folhas.")
    validacao = set()
    for classe in sorted(classes):
        grupos = sorted(treino[classe])
        if len(grupos) < 2 or classe not in classes_teste:
            raise ValueError(f"A classe {classe} não tem grupos suficientes para treino/validação/teste.")
        random.Random(f"{seed}:{classe}").shuffle(grupos)
        n = max(1, min(len(grupos) - 1, round(len(grupos) * fracao)))
        validacao.update(grupos[:n])
    for r in registros:
        if r["split"] == "train" and r["grupo"] in validacao:
            r["split"] = "val"
    return registros


def preparar(cache, destino, classes=None, fracao=0.15, seed=42):
    classes = sorted(classes or CATALOGO)
    destino = destino.resolve()
    if destino.exists():
        raise ValueError(f"O destino já existe e será preservado: {destino}. Use outro --destino.")
    registros = planejar(cache, classes, fracao, seed)
    temporario = destino.with_name(destino.name + ".preparando")
    if temporario.exists():
        raise ValueError(f"Existe uma preparação interrompida em {temporario}. Revise essa pasta ou use outro destino.")
    temporario.mkdir(parents=True)
    hashes = {}
    contagens = {s: {c: 0 for c in classes} for s in ("train", "val", "test")}
    with zipfile.ZipFile(cache / "data.zip") as arquivo:
        nomes = set(arquivo.namelist())
        pais = {}

        def raiz(grupo):
            pais.setdefault(grupo, grupo)
            while pais[grupo] != grupo:
                pais[grupo] = pais[pais[grupo]]
                grupo = pais[grupo]
            return grupo

        # Une também grupos com bytes idênticos antes de dividir treino/validação.
        # O processamento em duas passagens evita manter o dataset todo na RAM.
        for i, r in enumerate(registros):
            nome = r["origem"]
            if nome not in nomes:
                raise ValueError(f"Imagem ausente no ZIP oficial: {nome}")
            info = arquivo.getinfo(nome)
            if info.file_size > 25 * 1024 * 1024:
                raise ValueError(f"Imagem excessivamente grande no ZIP: {nome}")
            conteudo = arquivo.read(nome)
            digest = hashlib.sha256(conteudo).hexdigest()
            if digest in hashes:
                anterior = hashes[digest]
                if anterior["classe"] != r["classe"]:
                    raise ValueError("Conteúdo idêntico com rótulos diferentes. Revise a fonte.")
                pais[raiz(r["grupo"])] = raiz(anterior["grupo"])
            hashes[digest] = r
            r["sha256"] = digest
            if i % 2000 == 0:
                print(f"Verificando {i + 1}/{len(registros)} imagens...", flush=True)
        for r in registros:
            r["grupo"] = raiz(r["grupo"])
        registros = dividir(registros, classes, fracao, seed)
        hashes = {}
        for i, r in enumerate(registros):
            digest = r["sha256"]
            if digest in hashes:
                continue
            hashes[digest] = r
            nome = r["origem"]
            relativo = Path(r["split"]) / r["classe"] / PurePosixPath(nome).name
            saida = temporario / relativo
            saida.parent.mkdir(parents=True, exist_ok=True)
            saida.write_bytes(arquivo.read(nome))
            r.update(arquivo=relativo.as_posix(), sha256=digest)
            contagens[r["split"]][r["classe"]] += 1
            if i % 2000 == 0:
                print(f"Preparando {i + 1}/{len(registros)} imagens...", flush=True)
    if any(n == 0 for counts in contagens.values() for n in counts.values()):
        raise ValueError("Uma classe ficou sem imagens após a remoção de duplicatas.")
    revisao = json.loads((cache / "revisao.json").read_text(encoding="utf-8")) if (cache / "revisao.json").exists() else {"revisao": "fonte local não verificada"}
    manifesto = {"versao": 2, "dataset": "PlantVillage", "fonte": "https://huggingface.co/datasets/mohanty/PlantVillage", "licenca_informada": "CC BY-SA 3.0; conferir na fonte", "revisao": revisao["revisao"], "seed": seed, "fracao_validacao_do_treino": fracao, "classes": classes, "contagens": contagens, "folhas_sem_mapa": sum(not r["folha_mapeada"] for r in registros), "nota": "Teste oficial mantido com remoção de duplicatas exatas; grupos que coincidam com o teste são excluídos do treino. Validação retirada do treino por grupos de folhas, unindo conteúdos idênticos. Identificadores sem mapeamento não garantem identidade física.", "imagens": list(hashes.values())}
    (temporario / "manifesto.json").write_text(json.dumps(manifesto, ensure_ascii=False, indent=2), encoding="utf-8")
    temporario.rename(destino)
    print(f"Dataset preparado em {destino}")
    print({s: sum(c.values()) for s, c in contagens.items()})
    return manifesto


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--baixar", action="store_true", help="baixa o pacote e os metadados oficiais (vários GB)")
    p.add_argument("--revisao", default=REVISAO_PADRAO, help="revisão da fonte; padrão: a usada no modelo incluído")
    p.add_argument("--cache", type=Path, default=RAIZ / "cache_plantvillage")
    p.add_argument("--destino", type=Path, default=RAIZ / "data_plantvillage")
    p.add_argument("--classes", nargs="+", help="opcional: pelo menos duas classes oficiais; padrão: todas as 38")
    p.add_argument("--fracao-validacao", type=float, default=0.15)
    p.add_argument("--seed", type=int, default=42)
    args = p.parse_args()
    if args.destino.exists():
        p.error("O destino já existe e não será sobrescrito. Use outro --destino.")
    if args.baixar:
        baixar(args.cache, args.revisao)
    faltantes = [n for n in ARQUIVOS if not (args.cache / n).is_file()]
    if faltantes:
        p.error("Faltam arquivos oficiais no cache. Execute com --baixar: " + ", ".join(faltantes))
    try:
        preparar(args.cache, args.destino, args.classes, args.fracao_validacao, args.seed)
    except (ValueError, OSError, zipfile.BadZipFile) as erro:
        p.exit(1, f"Preparação interrompida: {erro}\nO destino antigo foi preservado; uma pasta .preparando pode ter ficado para inspeção.\n")


if __name__ == "__main__":
    main()
