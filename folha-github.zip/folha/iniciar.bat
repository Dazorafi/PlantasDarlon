@echo off
setlocal
cd /d "%~dp0"
where py >nul 2>nul
if errorlevel 1 goto usar_python
py -3 run_pipeline.py --somente-api
goto finalizar
:usar_python
where python >nul 2>nul
if errorlevel 1 goto sem_python
python run_pipeline.py --somente-api
goto finalizar
:sem_python
echo Instale o Python 3.11 ou superior de 64 bits e marque Add Python to PATH.
echo Download: https://www.python.org/downloads/
:finalizar
echo.
echo Se ocorreu algum erro, consulte o README.md antes de fechar esta janela.
pause
