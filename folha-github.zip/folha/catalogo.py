"""Taxonomia PlantVillage e manejo educativo. Fontes consultadas em 17/11/2026."""
from copy import deepcopy

PLANTAS = {"Apple": "Macieira", "Blueberry": "Mirtilo", "Cherry_(including_sour)": "Cerejeira", "Corn_(maize)": "Milho", "Grape": "Videira", "Orange": "Laranjeira", "Peach": "Pessegueiro", "Pepper,_bell": "Pimentão", "Potato": "Batata", "Raspberry": "Framboeseira", "Soybean": "Soja", "Squash": "Abóbora", "Strawberry": "Morangueiro", "Tomato": "Tomateiro"}
ROTULOS = {
    "Apple": [("Apple_scab", "Sarna da macieira", "geral"), ("Black_rot", "Podridão-negra", "geral"), ("Cedar_apple_rust", "Ferrugem da macieira", "geral"), ("healthy", "Aspecto saudável", "saudavel")],
    "Blueberry": [("healthy", "Aspecto saudável", "saudavel")],
    "Cherry_(including_sour)": [("Powdery_mildew", "Oídio", "oidio"), ("healthy", "Aspecto saudável", "saudavel")],
    "Corn_(maize)": [("Cercospora_leaf_spot Gray_leaf_spot", "Cercosporiose", "geral"), ("Common_rust_", "Ferrugem-comum", "geral"), ("Northern_Leaf_Blight", "Helmintosporiose do milho", "geral"), ("healthy", "Aspecto saudável", "saudavel")],
    "Grape": [("Black_rot", "Podridão-negra", "geral"), ("Esca_(Black_Measles)", "Esca (doença do lenho)", "esca"), ("Leaf_blight_(Isariopsis_Leaf_Spot)", "Mancha foliar de Isariopsis", "geral"), ("healthy", "Aspecto saudável", "saudavel")],
    "Orange": [("Haunglongbing_(Citrus_greening)", "Huanglongbing (HLB / greening)", "hlb")],
    "Peach": [("Bacterial_spot", "Mancha bacteriana", "geral"), ("healthy", "Aspecto saudável", "saudavel")],
    "Pepper,_bell": [("Bacterial_spot", "Mancha bacteriana", "geral"), ("healthy", "Aspecto saudável", "saudavel")],
    "Potato": [("Early_blight", "Pinta-preta", "geral"), ("Late_blight", "Requeima", "requeima"), ("healthy", "Aspecto saudável", "saudavel")],
    "Raspberry": [("healthy", "Aspecto saudável", "saudavel")],
    "Soybean": [("healthy", "Aspecto saudável", "saudavel")],
    "Squash": [("Powdery_mildew", "Oídio", "oidio")],
    "Strawberry": [("Leaf_scorch", "Queima das folhas do morangueiro", "geral"), ("healthy", "Aspecto saudável", "saudavel")],
    "Tomato": [("Bacterial_spot", "Mancha bacteriana", "manchas"), ("Early_blight", "Pinta-preta", "manchas"), ("Late_blight", "Requeima", "requeima"), ("Leaf_Mold", "Mofo-das-folhas", "geral"), ("Septoria_leaf_spot", "Septoriose", "manchas"), ("Spider_mites Two-spotted_spider_mite", "Possível dano por ácaro-rajado", "acaro"), ("Target_Spot", "Mancha-alvo", "geral"), ("Tomato_Yellow_Leaf_Curl_Virus", "Vírus do enrolamento amarelo das folhas", "tylcv"), ("Tomato_mosaic_virus", "Mosaico do tomateiro", "mosaico"), ("healthy", "Aspecto saudável", "saudavel")],
}
FONTES = {
    "ipm": {"titulo": "UC IPM — Manejo integrado", "url": "https://ipm.ucanr.edu/what-is-ipm/"},
    "manchas": {"titulo": "University of Minnesota — Manchas do tomateiro", "url": "https://extension.umn.edu/plant-diseases/tomato-leaf-spot-diseases"},
    "acaro": {"titulo": "University of Minnesota — Ácaro-rajado", "url": "https://extension.umn.edu/yard-and-garden-insects/spider-mites"},
    "oidio": {"titulo": "University of Minnesota — Oídio", "url": "https://extension.umn.edu/garden-and-home/yard-and-garden/gardening-in-minnesota/yard-and-garden-problems/powdery-mildew-in-the-flower-garden"},
    "esca": {"titulo": "UC IPM — Esca da videira", "url": "https://ipm.ucanr.edu/agriculture/grape/esca-black-measles/"},
    "hlb": {"titulo": "Ministério da Agricultura — HLB / greening", "url": "https://www.gov.br/agricultura/pt-br/assuntos/sanidade-animal-e-vegetal/sanidade-vegetal/pragas-quarentenarias-presentes/HLB"},
    "tylcv": {"titulo": "UC IPM — Enrolamento amarelo do tomateiro", "url": "https://ipm.ucanr.edu/agriculture/tomato/tomato-yellow-leaf-curl/"},
    "mosaico": {"titulo": "UC IPM — Mosaicos por tobamovírus", "url": "https://ipm.ucanr.edu/agriculture/tomato/tobacco-mosaic/"},
    "requeima": {"titulo": "UC IPM — Requeima do tomateiro", "url": "https://ipm.ucanr.edu/agriculture/tomato/late-blight/"},
}
GRUPOS = {
    "geral": ("Orientação inicial de manejo integrado; a causa precisa ser confirmada.", ["Observe folhas, caules e frutos e registre a evolução dos sintomas.", "Procure assistência agronômica para confirmar a causa antes de escolher o controle.", "Não aplique produtos apenas com base nesta classificação."], ["ipm"]),
    "saudavel": ("A imagem se parece com exemplos saudáveis do treinamento. Isso não descarta outras doenças.", ["Continue observando a planta e fotografe qualquer mudança.", "Se houver sintomas persistentes, procure avaliação mesmo com este resultado."], ["ipm"]),
    "manchas": ("Diferentes causas de manchas podem se parecer nas fases iniciais.", ["Evite molhar a folhagem na irrigação e favoreça a ventilação.", "Evite manusear plantas com folhas molhadas.", "Confirme a causa antes de remover partes ou aplicar produtos."], ["manchas"]),
    "acaro": ("O ácaro-rajado é uma praga; a foto da folha não confirma a presença do organismo.", ["Inspecione o verso das folhas com lupa, procurando ácaros e teias.", "Monitore plantas próximas e evite estresse por falta de água.", "Confirme a praga antes de escolher o controle."], ["acaro"]),
    "oidio": ("Oídio pode produzir aspecto esbranquiçado na superfície foliar.", ["Favoreça ventilação e evite excesso de adubação nitrogenada.", "Peça confirmação da doença e orientação específica para a cultura."], ["oidio"]),
    "esca": ("Esca envolve o lenho da videira; uma folha isolada não basta para confirmar.", ["Marque a planta e peça inspeção profissional de ramos e tronco.", "Pulverização foliar não elimina uma infecção estabelecida no lenho."], ["esca"]),
    "hlb": ("HLB é uma doença grave dos citros; plantas infectadas não têm cura conhecida.", ["Solicite confirmação à assistência agronômica ou defesa vegetal local.", "Não transporte mudas ou material da planta suspeita.", "O manejo do vetor e o destino de plantas confirmadas dependem de orientação técnica local."], ["hlb"]),
    "tylcv": ("Outros problemas também enrolam e amarelam folhas; confirme esta hipótese.", ["Verifique a presença de mosca-branca e peça orientação sobre manejo integrado do vetor.", "Use mudas sadias e avalie cultivares resistentes adequadas à região.", "Discuta o destino de plantas confirmadas com assistência técnica."], ["tylcv"]),
    "mosaico": ("Mosaicos podem ser transmitidos por contato e material contaminado.", ["Higienize mãos e ferramentas entre plantas e evite manusear plantas suspeitas.", "Use sementes e mudas de procedência conhecida e peça confirmação técnica.", "Controle de insetos não é solução automática para este mosaico."], ["mosaico"]),
    "requeima": ("A requeima pode avançar rapidamente; sintomas semelhantes exigem confirmação.", ["Procure assistência técnica com prioridade e examine plantas próximas.", "Evite manter a folhagem molhada e favoreça a circulação de ar.", "Defina o manejo específico para tomate ou batata com um profissional."], ["requeima"]),
}
CATALOGO = {}
for planta, entradas in ROTULOS.items():
    for rotulo, nome, grupo in entradas:
        chave = f"{planta}___{rotulo}"
        resumo, passos, fontes = GRUPOS[grupo]
        CATALOGO[chave] = {"classe": chave, "planta": PLANTAS[planta], "doenca": nome, "saudavel": grupo == "saudavel", "resumo": resumo, "orientacoes": passos, "fontes": [FONTES[f] for f in fontes]}

AVISO = ("Triagem educativa por imagem, sem diagnóstico definitivo. A confiança é a pontuação do modelo entre as classes conhecidas, não uma probabilidade de acerto calibrada. Fotos fora do PlantVillage, plantas não previstas e outros problemas podem ser classificados incorretamente, mesmo com pontuação alta. Confirme com assistência agronômica antes de intervir.")
AVISO_PRODUTOS = "Este sistema não prescreve produtos, doses ou receitas. O manejo depende da confirmação da causa, da cultura e das condições locais."


def validar_classes(classes):
    if len(classes) < 2 or len(set(classes)) != len(classes):
        raise ValueError("O modelo precisa de pelo menos duas classes únicas do PlantVillage.")
    desconhecidas = set(classes) - CATALOGO.keys()
    if desconhecidas:
        raise ValueError("Classes incompatíveis com PlantVillage: " + ", ".join(sorted(desconhecidas)))


def obter_classe(classe):
    return deepcopy(CATALOGO[classe])
