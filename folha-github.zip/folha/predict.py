"""Classifica uma imagem ou pasta e mostra hipóteses e manejo no terminal."""
import argparse
import json
from pathlib import Path
from api import CAMINHO_MODELO, LIMITE_BYTES, Preditor, abrir_imagem
from diagnostico import interpretar


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("caminho", type=Path)
    p.add_argument("--modelo", type=Path, default=CAMINHO_MODELO)
    args = p.parse_args()
    if not args.modelo.is_file():
        p.error("Modelo PlantVillage ausente. Prepare os dados e treine primeiro; consulte README.md.")
    if not args.caminho.exists():
        p.error("Imagem ou pasta não encontrada.")
    preditor = Preditor(args.modelo)
    extensoes = {".jpg", ".jpeg", ".png", ".webp"}
    arquivos = sorted(f for f in args.caminho.rglob("*") if f.is_file() and f.suffix.lower() in extensoes) if args.caminho.is_dir() else [args.caminho]
    if not arquivos:
        p.error("Nenhuma imagem compatível encontrada.")
    falhas = 0
    for arquivo in arquivos:
        try:
            if arquivo.stat().st_size > LIMITE_BYTES:
                raise ValueError("Imagem maior que 10 MB.")
            with abrir_imagem(arquivo.read_bytes()) as img:
                resposta = interpretar(preditor.classes, preditor.prever(img))
            print(json.dumps({"arquivo": str(arquivo), **resposta}, ensure_ascii=False, indent=2))
        except Exception as erro:
            falhas += 1
            print(f"Falha em {arquivo.name}: {getattr(erro, 'detail', str(erro))}")
    if falhas:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
