# Modelo incluído

`plantvillage.pth` é o checkpoint multiclasses usado pela aplicação. Ele está
incluído no Git comum, pesa aproximadamente **6,36 MB** e dispensa as fotos do
dataset para analisar novas imagens.

## Configuração

- Rede: MobileNetV3 Small, com 38 saídas.
- Inicialização: pesos ImageNet, seguida de ajuste de toda a rede.
- Entrada: RGB, recorte de avaliação de 224 × 224 e normalização ImageNet.
- Treino: 10 épocas, lote de 32, AdamW, taxa inicial 0,001 e redução por cosseno.
- Semente: 42. Execução em CPU.
- Ambiente original: Python 3.14.5, torch 2.15.0+cpu e torchvision 0.29.2+cpu.
- Fonte: PlantVillage, revisão `9e97599868962bd0079b8db4b7f1efa9185fa1e7`.
- O checkpoint guarda pesos, classes, arquitetura e identificação do manifesto.

## Resultados

| Medida | Valor |
|---|---:|
| Imagens de treino | 36.825 |
| Imagens de validação | 6.467 |
| Imagens de teste | 10.707 |
| Melhor época | 10 |
| Acurácia de validação | 99,71% |
| Acurácia de teste | 99,56% |
| F1 macro de teste | 0,9946 |
| Respostas inconclusivas no teste | 31 |

Os números descrevem o conjunto preparado do PlantVillage, após agrupamento e
remoção de duplicatas. Não garantem o mesmo desempenho em fotos de campo.
Consulte [métricas por categoria](../docs/avaliacao.json).

## Integridade

SHA-256 do arquivo distribuído:

```text
9fee66dae62814b7e246668abc0b6093bf978ea247346886dea71ff10eabf317
```

Os metadados portáveis estão em [metadata.json](metadata.json). Em uma nova
execução de treinamento, o checkpoint e seu hash podem mudar; estes metadados
descrevem especificamente a versão publicada.

## Limites

A pontuação é softmax não calibrado. O modelo sempre compara categorias
conhecidas; ele não valida que a imagem seja de uma planta prevista nem que a
causa dos sintomas pertença à base. Há culturas com cobertura incompleta, como
laranja, representada por HLB. A classificação não substitui diagnóstico
agronômico ou autorização para aplicar produtos.

Os dados não são incluídos. Fontes e atribuição:
[PlantVillage dos autores](https://github.com/spMohanty/PlantVillage-Dataset),
[distribuição oficial e termos dos dados](https://huggingface.co/datasets/mohanty/PlantVillage)
e [Mohanty, Hughes e Salathé (2016)](https://doi.org/10.3389/fpls.2016.01419).
