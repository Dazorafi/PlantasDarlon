# Folha — triagem de doenças em plantas

Envie a foto de uma folha e receba uma **possível doença**, a pontuação do modelo,
até três hipóteses e orientações educativas de manejo com fontes.

O repositório inclui uma **MobileNetV3 Small já treinada**, com 38 categorias do
PlantVillage. O modelo tem aproximadamente **6,36 MB**. **Não é necessário baixar
as fotos nem treinar novamente para usar a aplicação.**

## Usar em outro computador

### Requisitos

- Python **3.11 ou superior, 64 bits**. A instalação foi testada em Windows com
  Python 3.14.5. Evite Python 3.14.1, incompatível com a versão de torchvision.
- Internet na primeira execução para instalar as bibliotecas.
- Espaço para as dependências de PyTorch; elas são maiores que o arquivo do modelo.
- GPU não é necessária. A instalação padrão utiliza CPU no Windows e Linux.

O fluxo foi verificado em uma cópia limpa no Windows, com ambiente virtual novo,
sem as pastas de fotos e sem utilizar o ambiente da máquina original. O projeto
também calcula os caminhos de forma portável, mas outros sistemas operacionais
não foram verificados neste trabalho.

### Caminho mais simples no Windows

1. No GitHub, escolha **Code → Download ZIP** e extraia o conteúdo. Também é
   possível clonar pelo Git.
2. Abra a pasta extraída que contém `README.md`, `run_pipeline.py` e `iniciar.bat`.
3. Dê dois cliques em **`iniciar.bat`** e mantenha a janela aberta.
4. Aguarde a instalação inicial e abra **http://127.0.0.1:8000**.
5. Envie uma foto de uma única folha e clique em **Analisar folha**.

O inicializador cria `venv/`, instala as dependências de inferência e inicia a
API com o modelo incluído. Nas próximas execuções, reutiliza o ambiente instalado.
Depois da primeira instalação, a análise funciona localmente sem enviar a foto
a outro serviço. Os links das fontes podem ser consultados pela internet.

### Executar pelo terminal

Abra o terminal **dentro da pasta do projeto**:

```powershell
python run_pipeline.py --somente-api
```

No macOS/Linux, use `python3` no lugar de `python` quando necessário. Interrompa o
servidor com `Ctrl+C`. Se a página estava aberta antes, atualize-a com `F5`.

Se a porta 8000 estiver ocupada:

```powershell
python run_pipeline.py --somente-api --porta 8001
```

Abra http://127.0.0.1:8001 nesse caso. A aplicação escuta somente em `127.0.0.1`.

### Instalação manual no Windows

Se preferir controlar cada etapa:

```powershell
python -m venv venv
.\venv\Scripts\python.exe -m pip install -r requirements-inferencia.txt
.\venv\Scripts\python.exe api.py
```

Não é necessário ativar o ambiente virtual. No macOS/Linux, os executáveis ficam
em `venv/bin/python`.

## Estrutura das pastas

```text
folha/
├── iniciar.bat                    # inicializador do Windows
├── run_pipeline.py                # instala, executa e, quando solicitado, treina
├── api.py                         # FastAPI e página local
├── ambiente.py                    # caches junto ao projeto; sem caminho fixo de disco
├── catalogo.py                    # categorias, nomes em português e manejo com fontes
├── diagnostico.py                 # hipóteses e critérios de resultado inconclusivo
├── modelo.py                      # arquiteturas e carregamento do checkpoint
├── dataset.py                     # transformações e verificação do dataset
├── train.py / evaluate.py         # treinamento e avaliação opcionais
├── predict.py                     # análise de imagens pelo terminal
├── preparar_plantvillage.py        # download e organização opcionais das fotos
├── requirements-web.txt
├── requirements-inferencia.txt   # suficiente para usar a aplicação
├── requirements.txt             # inclui treinamento e avaliação
├── requirements-dev.txt         # inclui dependências dos testes
├── modelos/
│   ├── plantvillage.pth          # modelo treinado: incluído no GitHub
│   ├── metadata.json             # versão, métricas, origem e hash do modelo
│   └── README.md                 # cartão do modelo
├── static/                       # HTML, CSS e JavaScript
├── tests/                        # testes automatizados
└── docs/                         # resultados e instruções complementares
```

Estas pastas são criadas localmente e **não entram no GitHub**:

```text
venv/                            # bibliotecas instaladas neste computador
.cache/                          # caches e temporários
cache_plantvillage/               # pacote original e metadados do dataset
data_plantvillage/                # fotos preparadas, somente para treinar/avaliar
├── manifesto.json
├── train/<planta___doenca>/*.jpg
├── val/<planta___doenca>/*.jpg
└── test/<planta___doenca>/*.jpg
resultados/                      # métricas, gráficos e logs de novas execuções
```

Os caminhos são relativos à pasta do código. O projeto pode ser instalado em
outro disco ou diretório; não depende de `E:\PlatVillage` nem de pastas pessoais.

## Baixar as fotos e reproduzir o treinamento — opcional

As fotos são necessárias **somente para treinar, melhorar ou avaliar novamente**
o modelo. O arquivo de imagens não é distribuído pelo repositório.

- [Fonte dos autores no Hugging Face](https://huggingface.co/datasets/mohanty/PlantVillage)
- [Repositório dos autores](https://github.com/spMohanty/PlantVillage-Dataset)
- [Download do pacote oficial usado neste projeto, aproximadamente 2,18 GB](https://huggingface.co/datasets/mohanty/PlantVillage/resolve/9e97599868962bd0079b8db4b7f1efa9185fa1e7/data.zip?download=true)

**Prefira o importador automático**, que baixa também os arquivos pequenos de
divisão e agrupamento das folhas:

```powershell
python preparar_plantvillage.py --baixar
python run_pipeline.py --arquitetura mobilenet --epocas 10 --batch 32
```

O pacote inclui variantes das imagens, mas o importador seleciona apenas as
imagens RGB. Ele fixa a revisão da fonte, mantém o teste oficial com remoção de
duplicatas, exclui do treino grupos que coincidam com o teste e separa 15% dos
grupos restantes para validação. O manifesto registra grupos, hashes e contagens.
O mapa não cobre a identidade física de todas as folhas; o identificador do nome
é usado como alternativa para agrupar variantes sem mapeamento.

O download, as imagens preparadas, os temporários e as bibliotecas podem ocupar
vários GB. Escolha a pasta do projeto no disco em que deseja armazená-los.
O treinamento em CPU pode demorar; esta execução usou 10 épocas. Resultados de
uma nova execução podem variar conforme hardware e versões das bibliotecas.

O importador preserva um destino já existente. Para outra preparação, use
`--destino OUTRA_PASTA` e ajuste `DIR_DADOS` em `config.py` para usar esse destino.

### Download manual

Coloque os arquivos oficiais neste formato:

```text
cache_plantvillage/
├── data.zip
├── leaf_grouping/leaf-map.json
└── splits/
    ├── color_train.txt
    └── color_test.txt
```

Os metadados ficam na [mesma revisão oficial](https://huggingface.co/datasets/mohanty/PlantVillage/tree/9e97599868962bd0079b8db4b7f1efa9185fa1e7).
O ZIP precisa conter caminhos `raw/color/<classe>/<imagem>`. Execute
`python preparar_plantvillage.py` sem `--baixar` para preparar os arquivos locais.
Não é preciso extrair o ZIP inteiro manualmente.

### Comandos de treinamento e avaliação

```powershell
# Treinar e avaliar, sem iniciar a tela
python run_pipeline.py --retreinar --sem-api

# Avaliar o modelo com o dataset preparado
.\venv\Scripts\python.exe evaluate.py

# Analisar uma foto ou pasta pelo terminal, sem precisar do dataset
.\venv\Scripts\python.exe predict.py "caminho\folha.jpg"
```

`requirements.txt` instala também as bibliotecas de treinamento. As arquiteturas
`mobilenet`, `resnet18` e `cnn` são suportadas. Reinicie a API depois de substituir
o modelo. O checkpoint é substituído atomicamente conforme a melhor validação.

## Resultados do modelo incluído

| Item | Resultado |
|---|---:|
| Categorias | 38 |
| Imagens de treino | 36.825 |
| Imagens de validação | 6.467 |
| Imagens de teste | 10.707 |
| Épocas | 10 |
| Acerto na validação | 99,71% |
| Acerto no teste | 99,56% |
| F1 macro no teste | 0,9946 |
| Resultados inconclusivos no teste | 31 |

As 38 categorias incluem combinações de planta/doença, folhas saudáveis e dano
por ácaros. Não significam 38 doenças diferentes. Consulte o
[cartão do modelo](modelos/README.md) e as [métricas por classe](docs/avaliacao.json).

![Curvas do treinamento](docs/curvas_treino.png)

## Limitações e manejo

O PlantVillage tem imagens predominantemente controladas. O desempenho em fotos
de campo pode ser menor. Plantas desconhecidas, objetos que não sejam folhas e
doenças fora das categorias podem receber uma pontuação alta incorreta.

A confiança é **softmax não calibrado**, não uma garantia de diagnóstico.
O sistema sinaliza resultado inconclusivo com pontuação abaixo de 0,70 ou
diferença abaixo de 0,15 entre as duas primeiras hipóteses. Esses limites são
experimentais e não substituem validação de campo. Nem toda cultura tem exemplos
saudáveis e de todas as doenças no dataset; por exemplo, a categoria de laranja
corresponde a HLB.

As orientações são educativas, com fontes em `catalogo.py`. Algumas são de
manejo integrado geral. O sistema não prescreve produtos, doses ou receitas.
Confirme a causa com assistência agronômica antes de intervir.

## API e formatos de imagem

| Rota | Função |
|---|---|
| `GET /` | Interface de envio |
| `GET /status` | Disponibilidade e categorias do modelo |
| `POST /analisar` | Análise, com multipart no campo `imagem` |
| `GET /docs` | Documentação interativa |

Aceita JPEG, PNG e WebP estáticos, até 10 MB, com pelo menos 64 pixels em cada
lado e no máximo 20 milhões de pixels. As imagens não são salvas pela aplicação.

## Testes

```powershell
.\venv\Scripts\python.exe -m pip install -r requirements-dev.txt
.\venv\Scripts\python.exe -m unittest discover -s tests -v
```

Os testes incluem agrupamento e deduplicação, proteção de dados existentes,
validação de uploads, respostas inconclusivas, rejeição do modelo antigo e um
treinamento pequeno com imagens artificiais. Eles verificam o software; as
métricas agrícolas acima foram obtidas com o dataset real.

## Publicar no GitHub

O `.gitignore` exclui fotos, ZIP, ambientes, caches, backups e registros locais.
Ele permite o modelo `modelos/plantvillage.pth`, de aproximadamente 6,36 MB.
O modelo é um arquivo Git comum; não é necessário instalar Git LFS para usá-lo.

Crie um repositório **vazio** no GitHub. Pelo GitHub Desktop, use **Add existing
repository** nesta pasta, revise os arquivos, faça o primeiro commit e então use
**Publish repository**. Pelo terminal, substitua
a URL de exemplo pela URL real do seu repositório:

```powershell
git add .
git status --short
git commit -m "Adiciona Folha com modelo treinado e documentação"
git remote add origin https://github.com/SEU_USUARIO/SEU_REPOSITORIO.git
git push -u origin main
```

Em uma cópia que ainda não tenha Git, execute `git init -b main` primeiro.
Se o Git pedir nome e email do autor, configure-os localmente com
`git config user.name "Seu nome"` e `git config user.email "seu-email"` antes do commit.
Não envie o ZIP do dataset e não use `git add -f` nas pastas ignoradas.

## Fontes e atribuição

- PlantVillage: [GitHub dos autores](https://github.com/spMohanty/PlantVillage-Dataset) e
  [distribuição oficial](https://huggingface.co/datasets/mohanty/PlantVillage).
  O card da fonte informa **CC BY-SA 3.0** para os dados, que não estão incluídos aqui.
- Mohanty, Hughes e Salathé (2016),
  [Using Deep Learning for Image-Based Plant Disease Detection](https://doi.org/10.3389/fpls.2016.01419).
- [UC IPM — manejo integrado](https://ipm.ucanr.edu/what-is-ipm/).
- Fontes específicas de manejo estão associadas às categorias em `catalogo.py`
  e aparecem na resposta da aplicação.
