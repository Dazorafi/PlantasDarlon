'use strict';
const $ = id => document.getElementById(id);
let arquivo = null, urlPrevia = null, pronto = false, ocupado = false;
let versao = 0;
const formato = new Intl.NumberFormat('pt-BR', {style:'percent', maximumFractionDigits:1});
const atualizarBotao = () => { $('analisar').disabled = !arquivo || !pronto || ocupado; };
function erro(texto) { $('erro').textContent = texto; $('erro').hidden = !texto; }
function limparResultado() { $('conteudo-resultado').hidden = true; $('vazio').hidden = false; }
function selecionar(novo) {
  if (ocupado) return;
  versao++; erro(''); limparResultado();
  if (urlPrevia) URL.revokeObjectURL(urlPrevia);
  urlPrevia = null; arquivo = null;
  if (novo) {
    if (!['image/jpeg','image/png','image/webp'].includes(novo.type)) erro('Escolha uma imagem JPG, PNG ou WebP.');
    else if (novo.size > 10 * 1024 * 1024) erro('A foto precisa ter no máximo 10 MB.');
    else if (novo.size === 0) erro('O arquivo está vazio.');
    else { arquivo = novo; urlPrevia = URL.createObjectURL(novo); }
  }
  if (urlPrevia) $('previa').src = urlPrevia;
  else $('previa').removeAttribute('src');
  $('previa').hidden = !arquivo; $('convite').hidden = !!arquivo;
  $('nome-arquivo').textContent = arquivo ? arquivo.name : 'Nenhuma imagem selecionada';
  $('limpar').hidden = !arquivo;
  if (!arquivo) $('imagem').value = '';
  atualizarBotao();
}
$('imagem').addEventListener('change', e => selecionar(e.target.files[0]));
$('limpar').addEventListener('click', () => selecionar(null));
$('previa').addEventListener('error', () => { selecionar(null); erro('Não foi possível abrir a imagem. Escolha outro arquivo.'); });
for (const nome of ['dragenter','dragover']) $('area-upload').addEventListener(nome, e => {e.preventDefault(); if(!ocupado) $('area-upload').classList.add('arrastando');});
for (const nome of ['dragleave','drop']) $('area-upload').addEventListener(nome, e => { e.preventDefault(); $('area-upload').classList.remove('arrastando'); });
$('area-upload').addEventListener('drop', e => { if (e.dataTransfer.files.length !== 1) return erro('Envie uma única imagem por vez.'); selecionar(e.dataTransfer.files[0]); });
async function status() {
  try {
    const resposta = await fetch('/status');
    if (!resposta.ok) throw new Error();
    const dados = await resposta.json(); pronto = dados.modelo_pronto;
    $('estado-modelo').textContent = dados.mensagem;
    $('estado-modelo').classList.toggle('pendente', !pronto);
    if (pronto) $('cobertura').textContent = `O modelo carregado reconhece ${dados.classes.length} categorias: ${dados.classes.join('; ')}.`;
  } catch { pronto = false; $('estado-modelo').textContent = 'Não foi possível conectar. Verifique se o servidor está aberto e recarregue a página.'; $('estado-modelo').classList.add('pendente'); }
  atualizarBotao();
}
function lista(id, itens, renderizar) {
  const destino = $(id); destino.replaceChildren();
  for (const item of itens) { const li = document.createElement('li'); renderizar(li,item); destino.append(li); }
}
function mostrar(dados) {
  const inc = dados.status === 'inconclusivo';
  $('selo').textContent = inc ? 'Resultado inconclusivo' : dados.saudavel ? 'Aspecto saudável' : 'Possível alteração';
  $('selo').classList.toggle('inconclusivo', inc);
  $('planta').textContent = dados.planta || 'Não foi possível definir a planta e a doença';
  $('doenca').textContent = dados.possivel_doenca || 'Vamos observar melhor?';
  $('mensagem').textContent = dados.mensagem;
  $('percentual').textContent = formato.format(dados.confianca); $('barra').value = dados.confianca;
  lista('hipoteses', dados.hipoteses, (li,h) => { const nome = document.createElement('span'); nome.textContent=h.doenca; const planta = document.createElement('small'); planta.textContent=h.planta; nome.append(planta); const valor=document.createElement('strong'); valor.textContent=formato.format(h.confianca); li.append(nome,valor); });
  $('titulo-manejo').textContent = inc ? 'Como obter uma avaliação melhor' : 'Orientações de manejo';
  lista('orientacoes', dados.orientacoes, (li,t) => li.textContent=t);
  lista('fontes', dados.fontes, (li,f) => { const a=document.createElement('a'); const url=new URL(f.url); if(url.protocol!=='https:') return; a.href=url.href; a.textContent=f.titulo; a.target='_blank'; a.rel='noopener noreferrer'; li.append(a); });
  $('aviso-produtos').textContent=dados.aviso_produtos; $('aviso').textContent=dados.aviso;
  $('vazio').hidden=true; $('conteudo-resultado').hidden=false;
  if (matchMedia('(max-width:760px)').matches) $('painel-resultado').scrollIntoView({behavior:'smooth',block:'start'});
}
$('formulario').addEventListener('submit', async e => {
  e.preventDefault(); if(!arquivo || !pronto || ocupado) return;
  const atual=versao; ocupado=true; erro(''); limparResultado(); atualizarBotao();
  $('imagem').disabled=true; $('limpar').disabled=true; $('painel-resultado').setAttribute('aria-busy','true');
  $('analisar').textContent='Analisando a folha…';
  const controle=new AbortController(), tempo=setTimeout(()=>controle.abort(),120000);
  try {
    const corpo=new FormData(); corpo.append('imagem',arquivo);
    const resposta=await fetch('/analisar',{method:'POST',body:corpo,signal:controle.signal});
    const dados=await resposta.json();
    if(!resposta.ok) throw new Error(typeof dados.detail==='string'?dados.detail:'Não foi possível analisar a imagem.');
    if(atual===versao) mostrar(dados);
  } catch(e) { erro(e.name==='AbortError'?'A análise demorou demais. Tente uma imagem menor.':e.message || 'Falha de conexão. Tente novamente.'); }
  finally { clearTimeout(tempo); ocupado=false; $('imagem').disabled=false; $('limpar').disabled=false; $('painel-resultado').removeAttribute('aria-busy'); $('analisar').textContent='Analisar folha ↗'; atualizarBotao(); }
});
status();
