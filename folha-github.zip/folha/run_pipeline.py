"""Prepara o ambiente, treina quando necessário, avalia e abre a API local."""
import ambiente  # caches e temporários no disco do projeto

import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import struct
import venv

RAIZ = Path(__file__).resolve().parent
VENV = RAIZ / "venv"
MODELO = RAIZ / "modelos" / "plantvillage.pth"
INFO = RAIZ / "modelos" / "plantvillage_treino_info.json"
DADOS = RAIZ / "data_plantvillage"
EM_ANDAMENTO = RAIZ / "modelos" / ".plantvillage_treino_em_andamento"
CODIGO = ("config.py", "dataset.py", "modelo.py", "train.py")


def python_venv():
    return VENV / ("Scripts/python.exe" if os.name == "nt" else "bin/python")


def rodar(comando):
    subprocess.run([str(x) for x in comando], cwd=RAIZ, check=True)


def hash_codigo():
    h = hashlib.sha256()
    for nome in CODIGO:
        arvore = ast.parse((RAIZ / nome).read_text(encoding="utf-8"))
        h.update(nome.encode())
        h.update(ast.dump(arvore, include_attributes=False).encode())
    return h.hexdigest()


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument("--arquitetura", default="mobilenet", choices=("mobilenet", "resnet18", "cnn"))
    p.add_argument("--epocas", type=int, default=10)
    p.add_argument("--batch", type=int, default=32)
    p.add_argument("--retreinar", action="store_true")
    p.add_argument("--sem-api", action="store_true")
    p.add_argument("--somente-api", action="store_true", help="abre a tela sem baixar dados nem treinar")
    p.add_argument("--porta", type=int, default=8000, help="porta local da interface (padrão: 8000)")
    args = p.parse_args()
    if sys.version_info < (3, 11) or struct.calcsize("P") != 8:
        p.error("Instale Python 3.11 ou superior de 64 bits. A instalação foi testada com Python 3.14.5.")
    if sys.version_info[:3] == (3, 14, 1):
        p.error("Python 3.14.1 é incompatível com torchvision. Atualize para outra versão de Python 3.14.")
    if not 1 <= args.porta <= 65535:
        p.error("A porta deve estar entre 1 e 65535.")
    if args.epocas < 1 or args.batch < 1:
        p.error("Épocas e lote precisam ser positivos.")
    if not args.somente_api and not (DADOS / "manifesto.json").is_file():
        p.error("Prepare os dados antes: python preparar_plantvillage.py --baixar. Para abrir só a tela: --somente-api")
    if not python_venv().exists():
        print("Criando ambiente virtual...", flush=True)
        venv.create(VENV, with_pip=True)
    arquivos_requisitos = [RAIZ / "requirements-web.txt"]
    if MODELO.exists() or not args.somente_api:
        arquivos_requisitos.append(RAIZ / "requirements-inferencia.txt")
    if not args.somente_api:
        arquivos_requisitos.append(RAIZ / "requirements.txt")
    digest = hashlib.sha256(b"".join(f.read_bytes() for f in arquivos_requisitos)).hexdigest()
    marca = VENV / ".plantvillage_requisitos"
    if not marca.exists() or marca.read_text() != digest:
        requisitos = arquivos_requisitos[-1]
        rodar([python_venv(), "-m", "pip", "install", "-r", requisitos])
        marca.write_text(digest)
    if not args.somente_api:
        # train.py e evaluate.py verificam o dataset antes de usar os dados.
        atual = {"codigo": hash_codigo(), "manifesto": hashlib.sha256((DADOS / "manifesto.json").read_bytes()).hexdigest(), "arquitetura": args.arquitetura, "epocas": args.epocas, "batch": args.batch}
        try:
            anterior = json.loads(INFO.read_text())
        except (OSError, ValueError):
            anterior = None
        if args.retreinar or not MODELO.exists() or atual != anterior or EM_ANDAMENTO.exists():
            MODELO.parent.mkdir(exist_ok=True)
            # Preserva o último modelo válido. train.py substitui o arquivo atomicamente.
            EM_ANDAMENTO.touch()
            rodar([python_venv(), "train.py", "--arquitetura", args.arquitetura, "--epocas", args.epocas, "--batch", args.batch])
            INFO.write_text(json.dumps(atual, indent=2), encoding="utf-8")
            EM_ANDAMENTO.unlink()
        else:
            print("Modelo atualizado: treinamento dispensado.", flush=True)
        # Avalia mesmo quando o treino foi dispensado, inclusive se uma avaliação anterior falhou.
        rodar([python_venv(), "evaluate.py"])
    if not args.sem_api:
        print(f"Abra http://127.0.0.1:{args.porta} — Ctrl+C para encerrar.", flush=True)
        rodar([python_venv(), "api.py", "--porta", args.porta])


if __name__ == "__main__":
    try:
        main()
    except subprocess.CalledProcessError as erro:
        raise SystemExit(f"Uma etapa falhou (código {erro.returncode}). Consulte o erro acima. O modelo antigo de duas classes foi preservado.")
    except KeyboardInterrupt:
        print("\nExecução encerrada.")
