"""Testes reais de PyTorch com imagens artificiais; não medem acurácia agrícola."""
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from test_projeto import CLASSES, criar_fonte, imagem
try:
    import torch
    import config
    import dataset
    from modelo import carregar_checkpoint, criar_modelo
except ImportError:
    torch = None


@unittest.skipIf(torch is None, "Instale requirements.txt para testar o treinamento.")
class TreinamentoTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        torch.set_num_threads(2)

    def test_tres_arquiteturas_38_classes(self):
        for arquitetura in ("mobilenet", "resnet18", "cnn"):
            with self.subTest(arquitetura=arquitetura):
                modelo = criar_modelo(arquitetura, 38, pretreinado=False).eval()
                with torch.inference_mode():
                    saida = modelo(torch.zeros(1, 3, 224, 224))
                self.assertEqual(tuple(saida.shape), (1, 38))
                self.assertTrue(torch.isfinite(saida).all())

    def test_modelo_binario_antigo_rejeitado(self):
        with tempfile.TemporaryDirectory() as pasta:
            caminho = Path(pasta) / "antigo.pth"
            torch.save({"classes": ["doente", "saudavel"], "arquitetura": "cnn", "state_dict": {}}, caminho)
            with self.assertRaises(ValueError):
                carregar_checkpoint(caminho)

    def test_preparar_treinar_avaliar_carregar_e_analisar(self):
        import train
        import evaluate
        from preparar_plantvillage import preparar
        from api import Preditor, criar_app
        from fastapi.testclient import TestClient
        with tempfile.TemporaryDirectory() as pasta:
            raiz = Path(pasta)
            cache = raiz / "cache"
            criar_fonte(cache)
            dados = raiz / "dados"
            preparar(cache, dados, CLASSES, .3)
            modelos, resultados = raiz / "modelos", raiz / "resultados"
            caminho = modelos / "plantvillage.pth"
            # zero workers só neste teste para evitar processos extras no Windows.
            original = dataset.criar_loader
            def loader(split, batch_size=4):
                return original(split, batch_size, num_workers=0)
            with patch.multiple(config, DIR_DADOS=dados, DIR_MODELOS=modelos, DIR_RESULTADOS=resultados, CAMINHO_MODELO=caminho):
                self.assertEqual(dataset.validar_dataset()["classes"], sorted(CLASSES))
                with patch.object(train, "criar_loader", loader), patch.object(sys, "argv", ["train.py", "--arquitetura", "cnn", "--epocas", "1", "--batch", "4"]):
                    train.main()
                self.assertTrue(caminho.exists())
                modelo, classes = carregar_checkpoint(caminho)
                self.assertEqual(classes, sorted(CLASSES))
                self.assertFalse(modelo.training)
                with patch.object(evaluate, "criar_loader", loader):
                    evaluate.main()
                metricas = json.loads((resultados / "metricas.json").read_text())
                self.assertEqual(metricas["total_teste"], 4)
                self.assertFalse(metricas["confianca_calibrada"])
                self.assertTrue((resultados / "matriz_confusao.png").exists())
                with TestClient(criar_app(Preditor(caminho))) as cliente:
                    r = cliente.post("/analisar", files={"imagem": ("folha.png", imagem())})
                    self.assertEqual(r.status_code, 200)
                    self.assertIn(r.json()["status"], ("hipotese", "inconclusivo"))
                primeira = next((dados / "train").rglob("*.png"))
                primeira.write_bytes(b"imagem alterada")
                with self.assertRaises(ValueError):
                    dataset.validar_dataset()


if __name__ == "__main__":
    unittest.main()
