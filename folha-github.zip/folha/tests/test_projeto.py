import io
import json
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import zipfile

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from PIL import Image, ImageDraw
from fastapi.testclient import TestClient
import api
from catalogo import CATALOGO, validar_classes
from diagnostico import interpretar
from preparar_plantvillage import grupo_folha, planejar, preparar

CLASSES = ["Tomato___Early_blight", "Tomato___healthy"]


def imagem(cor=(35, 140, 60), tamanho=(96, 96), formato="PNG"):
    saida = io.BytesIO()
    with Image.new("RGB", tamanho, cor) as img:
        ImageDraw.Draw(img).rectangle((10, 10, 30, 30), fill=(cor[2], cor[0], cor[1]))
        img.save(saida, format=formato)
    return saida.getvalue()


def criar_fonte(cache):
    """Duas categorias, fotos diferentes da mesma folha e uma coincidência oficial."""
    (cache / "splits").mkdir(parents=True)
    (cache / "leaf_grouping").mkdir()
    manifesto = {"train": [], "test": []}
    mapa = {}
    with zipfile.ZipFile(cache / "data.zip", "w") as z:
        for c, classe in enumerate(CLASSES):
            for i in range(8):
                mapa[f"leaf-{c}-{i}"] = [f"{classe}:::{i}"]
                for copia in range(2 if i < 6 else 1):
                    nome = f"raw/color/{classe}/uuid-{c}-{i}-{copia}___leaf-{c}-{i}{' copy' if copia else ''}.png"
                    split = "train" if i < 6 else "test"
                    manifesto[split].append(nome)
                    z.writestr(nome, imagem((c * 70 + 20, i * 20 + 30, copia * 50 + i)))
            # Esta foto da mesma folha já presente no teste deve sair do treino.
            nome = f"raw/color/{classe}/uuid-extra___leaf-{c}-6 copy.png"
            manifesto["train"].append(nome)
            z.writestr(nome, imagem((240, 50, c * 40)))
    for s, linhas in manifesto.items():
        (cache / f"splits/color_{s}.txt").write_text("\n".join(linhas), encoding="utf-8")
    (cache / "leaf_grouping/leaf-map.json").write_text(json.dumps(mapa), encoding="utf-8")


class InterpretacaoTests(unittest.TestCase):
    def test_taxonomia_completa_e_modelo_antigo_rejeitado(self):
        self.assertEqual(len(CATALOGO), 38)
        with self.assertRaises(ValueError):
            validar_classes(["doente", "saudavel"])
        for item in CATALOGO.values():
            self.assertTrue(item["orientacoes"])
            self.assertTrue(item["fontes"])

    def test_hipotese_com_manejo_e_fontes(self):
        r = interpretar(CLASSES, [.93, .07])
        self.assertEqual(r["status"], "hipotese")
        self.assertEqual(r["possivel_doenca"], "Pinta-preta")
        self.assertFalse(r["saudavel"])
        self.assertTrue(r["fontes"])
        self.assertFalse(r["confianca_calibrada"])

    def test_inconclusivo_nao_exibe_manejo_especifico(self):
        r = interpretar(CLASSES, [.51, .49])
        self.assertEqual(r["status"], "inconclusivo")
        self.assertIsNone(r["possivel_doenca"])
        self.assertEqual(r["fontes"], [])
        self.assertEqual(len(r["hipoteses"]), 2)
        self.assertEqual(interpretar(CLASSES, [.73, .27], margem_minima=.5)["status"], "inconclusivo")

    def test_saudavel_nao_promete_ausencia_de_doenca(self):
        r = interpretar(CLASSES, [.02, .98])
        self.assertTrue(r["saudavel"])
        self.assertIn("não descarta", r["mensagem"])

    def test_probabilidades_invalidas(self):
        for probs in ([float("nan"), .1], [-.2, 1.2], [.2, .2], [.9]):
            with self.subTest(probs=probs), self.assertRaises(ValueError):
                interpretar(CLASSES, probs)


class PreditorTeste:
    classes = CLASSES
    def prever(self, img):
        assert img.mode == "RGB"
        return [.94, .06]


class ApiTests(unittest.TestCase):
    def test_tela_sem_modelo_nao_fabrica_diagnostico(self):
        with patch.object(api, "CAMINHO_MODELO", Path("modelo_que_nao_existe.pth")):
            with TestClient(api.criar_app()) as c:
                self.assertEqual(c.get("/").status_code, 200)
                self.assertEqual(c.get("/static/app.js").status_code, 200)
                self.assertFalse(c.get("/status").json()["modelo_pronto"])
                self.assertEqual(c.post("/analisar", files={"imagem": ("folha.png", imagem())}).status_code, 503)

    def test_upload_real_resposta_integrada(self):
        with TestClient(api.criar_app(PreditorTeste())) as c:
            self.assertTrue(c.get("/status").json()["modelo_pronto"])
            r = c.post("/analisar", files={"imagem": ("<script>.png", imagem(), "image/png")})
            self.assertEqual(r.status_code, 200)
            self.assertEqual(r.json()["possivel_doenca"], "Pinta-preta")
            self.assertEqual(r.json()["confianca"], .94)
            self.assertTrue(r.json()["orientacoes"])

    def test_arquivos_invalidos_e_limites(self):
        with TestClient(api.criar_app(PreditorTeste())) as c:
            for dados, status in [(b"", 400), (b"nao e imagem", 400), (imagem(tamanho=(20, 20)), 400), (imagem(formato="GIF"), 415), (b"x" * (api.LIMITE_BYTES + 1), 413)]:
                with self.subTest(status=status):
                    self.assertEqual(c.post("/analisar", files={"imagem": ("foto.png", dados)}).status_code, status)
            self.assertEqual(c.post("/analisar").status_code, 422)
        with patch.object(api, "LIMITE_PIXELS", 100):
            with self.assertRaises(api.HTTPException) as contexto:
                api.abrir_imagem(imagem())
            self.assertEqual(contexto.exception.status_code, 413)

    def test_falha_preditor_nao_expoe_detalhe_interno(self):
        preditor = PreditorTeste()
        with patch.object(preditor, "prever", side_effect=RuntimeError("detalhe interno")):
            with TestClient(api.criar_app(preditor)) as c:
                r = c.post("/analisar", files={"imagem": ("foto.png", imagem())})
                self.assertEqual(r.status_code, 500)
                self.assertNotIn("detalhe interno", r.text)


class PreparacaoTests(unittest.TestCase):
    def test_identificador_com_ponto_e_copia(self):
        caminho = "raw/color/Potato___Early_blight/uuid___RS_Early.B 7557 copy 2.JPG"
        mapa = {"rs_early.b 7557": ["Potato___Early_blight:::115.0"]}
        self.assertEqual(grupo_folha(caminho, mapa), ("Potato___Early_blight:::115.0", True))

    def test_preparacao_sem_vazamento_e_sem_sobrescrever(self):
        with tempfile.TemporaryDirectory() as pasta:
            cache = Path(pasta) / "cache"
            criar_fonte(cache)
            destino = Path(pasta) / "dados"
            m = preparar(cache, destino, CLASSES, .3)
            conjuntos = {}
            for r in m["imagens"]:
                self.assertTrue((destino / r["arquivo"]).is_file())
                self.assertEqual(conjuntos.setdefault(r["grupo"], r["split"]), r["split"])
            self.assertEqual(sum(m["contagens"]["test"].values()), 4)
            self.assertEqual(sum(sum(c.values()) for c in m["contagens"].values()), 28)
            with self.assertRaises(ValueError):
                preparar(cache, destino, CLASSES)

    def test_caminho_malicioso_rejeitado(self):
        with tempfile.TemporaryDirectory() as pasta:
            cache = Path(pasta) / "cache"
            criar_fonte(cache)
            with (cache / "splits/color_train.txt").open("a", encoding="utf-8") as f:
                f.write("\n../../arquivo.png")
            with self.assertRaises(ValueError):
                planejar(cache, CLASSES)

    def test_bytes_iguais_ficam_no_mesmo_conjunto(self):
        with tempfile.TemporaryDirectory() as pasta:
            cache = Path(pasta) / "cache"
            criar_fonte(cache)
            # Acrescenta um arquivo do treino com o mesmo conteúdo de um arquivo de teste.
            nome = f"raw/color/{CLASSES[0]}/uuid-duplicate___nova-folha.png"
            with zipfile.ZipFile(cache / "data.zip", "a") as z:
                original = next(n for n in z.namelist() if "leaf-0-6.png" in n)
                z.writestr(nome, z.read(original))
            with (cache / "splits/color_train.txt").open("a", encoding="utf-8") as f:
                f.write("\n" + nome)
            m = preparar(cache, Path(pasta) / "dados", CLASSES)
            hashes = {}
            for r in m["imagens"]:
                self.assertNotIn(r["sha256"], hashes)
                hashes[r["sha256"]] = r["split"]


if __name__ == "__main__":
    unittest.main()
