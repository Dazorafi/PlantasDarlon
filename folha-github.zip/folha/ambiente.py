"""Mantém caches e temporários deste projeto junto ao código, sem alterar o Windows."""
import os
from pathlib import Path

RAIZ = Path(__file__).resolve().parent
CACHE = RAIZ / ".cache"
TEMPORARIOS = CACHE / "temp"
TEMPORARIOS.mkdir(parents=True, exist_ok=True)
for nome, pasta in {
    "PIP_CACHE_DIR": CACHE / "pip",
    "TORCH_HOME": CACHE / "torch",
    "HF_HOME": CACHE / "huggingface",
    "MPLCONFIGDIR": CACHE / "matplotlib",
}.items():
    os.environ[nome] = str(pasta)
# Apenas o processo do projeto e seus subprocessos usam estes temporários.
os.environ["TEMP"] = str(TEMPORARIOS)
os.environ["TMP"] = str(TEMPORARIOS)
