"""Interpretação independente de PyTorch, compartilhada pela API e terminal."""
import math
from catalogo import AVISO, AVISO_PRODUTOS, obter_classe, validar_classes


def interpretar(classes, probabilidades, limiar=0.70, margem_minima=0.15):
    validar_classes(classes)
    if len(classes) != len(probabilidades):
        raise ValueError("Quantidade de probabilidades incompatível com as classes.")
    if not 0 <= limiar <= 1 or not 0 <= margem_minima <= 1:
        raise ValueError("Limiares precisam estar entre 0 e 1.")
    valores = [float(p) for p in probabilidades]
    if any(not math.isfinite(p) or not 0 <= p <= 1 for p in valores) or not math.isclose(sum(valores), 1, abs_tol=1e-4):
        raise ValueError("Probabilidades inválidas.")
    indices = sorted(range(len(classes)), key=lambda i: valores[i], reverse=True)
    primeiro, segundo = indices[:2]
    conf = valores[primeiro]
    margem = conf - valores[segundo]
    inconclusivo = conf < limiar or margem < margem_minima
    hipoteses = []
    for i in indices[:3]:
        item = obter_classe(classes[i])
        hipoteses.append({k: item[k] for k in ("classe", "planta", "doenca", "saudavel")} | {"confianca": round(valores[i], 6)})
    resultado = obter_classe(classes[primeiro])
    return {
        "status": "inconclusivo" if inconclusivo else "hipotese",
        "resultado": "inconclusivo" if inconclusivo else resultado["classe"],
        "planta": None if inconclusivo else resultado["planta"],
        "possivel_doenca": None if inconclusivo else resultado["doenca"],
        "saudavel": None if inconclusivo else resultado["saudavel"],
        "confianca": round(conf, 6), "margem": round(margem, 6),
        "limiar": limiar, "margem_minima": margem_minima,
        "mensagem": "Não foi possível distinguir as hipóteses com segurança. Envie outra foto nítida de uma única folha." if inconclusivo else resultado["resumo"],
        "hipoteses": hipoteses,
        "orientacoes": ["Fotografe uma única folha, frente e verso, com luz natural e fundo simples.", "Busque assistência técnica se os sintomas persistirem."] if inconclusivo else resultado["orientacoes"],
        "fontes": [] if inconclusivo else resultado["fontes"],
        "aviso": AVISO, "aviso_produtos": AVISO_PRODUTOS, "confianca_calibrada": False,
    }
