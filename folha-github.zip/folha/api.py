"""Página local e API. A tela funciona antes de existir um modelo treinado."""
import ambiente  # caches e temporários no disco do projeto

from contextlib import asynccontextmanager
from pathlib import Path
from threading import Lock
import io
import logging
import time
import warnings
from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse
from fastapi.staticfiles import StaticFiles
from PIL import Image, ImageOps, UnidentifiedImageError
from starlette.concurrency import run_in_threadpool
from catalogo import CATALOGO, validar_classes
from diagnostico import interpretar

RAIZ = Path(__file__).resolve().parent
CAMINHO_MODELO = RAIZ / "modelos" / "plantvillage.pth"
LIMITE_BYTES = 10 * 1024 * 1024
LIMITE_PIXELS = 20_000_000
FORMATOS = {"JPEG", "PNG", "WEBP"}
MENSAGEM_PREPARO = "O modelo treinado não foi encontrado. Verifique se modelos/plantvillage.pth foi baixado junto com o projeto. Para treinar outro modelo, consulte o README.md."
logger = logging.getLogger(__name__)


class Preditor:
    def __init__(self, caminho):
        import config
        import torch
        from dataset import transform_avaliacao
        from modelo import carregar_checkpoint
        self.torch = torch
        self.device = config.dispositivo()
        self.modelo, self.classes = carregar_checkpoint(caminho, self.device)
        validar_classes(self.classes)
        self.transform = transform_avaliacao()
        self.lock = Lock()

    def prever(self, img):
        with self.lock, self.torch.inference_mode():
            x = self.transform(img).unsqueeze(0).to(self.device)
            return self.torch.softmax(self.modelo(x), dim=1)[0].cpu().tolist()


def abrir_imagem(conteudo):
    try:
        with warnings.catch_warnings():
            warnings.simplefilter("error", Image.DecompressionBombWarning)
            with Image.open(io.BytesIO(conteudo)) as img:
                if img.format not in FORMATOS:
                    raise HTTPException(415, "Use uma imagem JPEG, PNG ou WebP.")
                if img.width * img.height > LIMITE_PIXELS:
                    raise HTTPException(413, "Imagem com mais de 20 milhões de pixels. Reduza a resolução.")
                if min(img.size) < 64:
                    raise HTTPException(400, "A imagem deve ter ao menos 64 pixels em cada lado.")
                if getattr(img, "n_frames", 1) != 1:
                    raise HTTPException(400, "Envie uma imagem estática, sem animação.")
                img.load()
                return ImageOps.exif_transpose(img).convert("RGB")
    except (Image.DecompressionBombError, Image.DecompressionBombWarning):
        raise HTTPException(413, "Imagem com resolução excessiva.") from None
    except (UnidentifiedImageError, OSError, ValueError):
        raise HTTPException(400, "O arquivo está corrompido ou não é uma imagem válida.") from None


def criar_app(preditor=None):
    @asynccontextmanager
    async def lifespan(app):
        if app.state.preditor is None:
            if not CAMINHO_MODELO.is_file():
                app.state.erro = MENSAGEM_PREPARO
            else:
                try:
                    app.state.preditor = await run_in_threadpool(Preditor, CAMINHO_MODELO)
                except Exception:
                    logger.exception("Não foi possível carregar o modelo PlantVillage")
                    app.state.erro = "O modelo não pôde ser carregado. Verifique as dependências e o treinamento."
        yield

    app = FastAPI(title="Folha — triagem de plantas", version="2.0", lifespan=lifespan)
    app.state.preditor = preditor
    app.state.erro = None
    app.mount("/static", StaticFiles(directory=RAIZ / "static"), name="static")

    @app.get("/", include_in_schema=False)
    def pagina():
        return FileResponse(RAIZ / "static" / "index.html")

    @app.get("/status")
    def status():
        atual = app.state.preditor
        return {"status": "pronto" if atual is not None else "aguardando_modelo", "modelo_pronto": atual is not None, "modelo": CAMINHO_MODELO.name, "classes": list(atual.classes) if atual is not None else [], "total_classes_catalogo": len(CATALOGO), "mensagem": "Modelo carregado. Envie uma foto de uma folha." if atual is not None else app.state.erro or MENSAGEM_PREPARO}

    @app.post("/analisar")
    async def analisar(request: Request, imagem: UploadFile = File(...)):
        try:
            atual = request.app.state.preditor
            if atual is None:
                raise HTTPException(503, request.app.state.erro or MENSAGEM_PREPARO)
            conteudo = await imagem.read(LIMITE_BYTES + 1)
            if not conteudo:
                raise HTTPException(400, "Arquivo vazio.")
            if len(conteudo) > LIMITE_BYTES:
                raise HTTPException(413, "Imagem maior que 10 MB.")
            inicio = time.perf_counter()
            img = await run_in_threadpool(abrir_imagem, conteudo)
            try:
                probabilidades = await run_in_threadpool(atual.prever, img)
                resposta = interpretar(atual.classes, probabilidades)
            except Exception:
                logger.exception("Falha na análise")
                raise HTTPException(500, "Não foi possível analisar a imagem. Verifique o modelo e tente novamente.") from None
            finally:
                img.close()
            resposta.update(arquivo=imagem.filename, tempo_ms=round((time.perf_counter() - inicio) * 1000, 1))
            return resposta
        finally:
            await imagem.close()

    return app


app = criar_app()
if __name__ == "__main__":
    import argparse
    import uvicorn
    parser = argparse.ArgumentParser(description="Interface local de análise de folhas.")
    parser.add_argument("--porta", type=int, default=8000)
    opcoes = parser.parse_args()
    if not 1 <= opcoes.porta <= 65535:
        parser.error("A porta deve estar entre 1 e 65535.")
    uvicorn.run(app, host="127.0.0.1", port=opcoes.porta)
